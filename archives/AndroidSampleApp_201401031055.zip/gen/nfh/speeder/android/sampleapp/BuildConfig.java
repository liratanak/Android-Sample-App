/** Automatically generated file. DO NOT MODIFY */
package nfh.speeder.android.sampleapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}